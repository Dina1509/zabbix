CHAT ROOM SAMPLE
-------------------------------
NCACHE FEATURES USED
--------------------
This sample deals with the following features of NCache.
	i)	Custom Notifications
	ii)	NCache Events
	
INTRODUCTION
------------
This is a sample application based on NCache custom events notification capability. 

DESCRIPTION
-----------
There is single winform application that constitutes this sample.
	i)	ChatRoom
		Simple winform application that is just like any other chat application. Once you have signed-in, you are using the NCache 
		clustering feature to comunicate with other users in the cluster 'MyReplicatedCache'. When you enter your message, a 
		custom notification about the new message is received at all other nodes in the cluster.

HOW TO RUN SAMPLE
-----------------
To run the sample
	1.	Make sure the cluster 'MyReplicatedCache' is running. To do this, start the NCache Manager from the start menu and open project 
		'ClusteredCaches' from the recent projects. When you install NCache this cluster is registered.
	2.	Run the cluster 'MyReplicatedCache'.
	3. 	Now Build the ChatRoom.sln from the path <NCache Root>\Samples\clr20\Chatroom .

CHATROOM settings:
-----------------

	RoomName:	the Cluster to be used for this application. By default it is 'MyReplicatedCache'.

	This setting for chatroom program can be changed from the 'Chatroom.exe.config' file located at:

	<NCache Root>\Samples\clr20\Chatroom\bin\
	OR
	<NCache Root>\Samples\clr10\Chatroom\bin\

Note
----
For NCache Developer Edition replace 'myReplicatedCache' with 'myCache' or any other local-cache.